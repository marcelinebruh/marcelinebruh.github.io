<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="row gy-4">
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Kaos Polos</h5>
        <p class="card-text mb-1">Harga: <strong>Rp 75.000</strong></p>
        <p class="card-text mb-1">Jumlah: <strong>1</strong></p>
        <p class="card-text">Subtotal: <strong>Rp 75.000</strong></p>
        <a href="#" class="btn btn-outline-danger btn-sm">Hapus</a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Sepatu Sneaker</h5>
        <p class="card-text mb-1">Harga: <strong>Rp 280.000</strong></p>
        <p class="card-text mb-1">Jumlah: <strong>1</strong></p>
        <p class="card-text">Subtotal: <strong>Rp 280.000</strong></p>
        <a href="#" class="btn btn-outline-danger btn-sm">Hapus</a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Jaket Denim</h5>
        <p class="card-text mb-1">Harga: <strong>Rp 190.000</strong></p>
        <p class="card-text mb-1">Jumlah: <strong>1</strong></p>
        <p class="card-text">Subtotal: <strong>Rp 190.000</strong></p>
        <a href="#" class="btn btn-outline-danger btn-sm">Hapus</a>
      </div>
    </div>
  </div>
  <div class="col-lg-6">
    <div class="card shadow-sm">
      <div class="card-body">
        <h5 class="card-title">Tas Ransel</h5>
        <p class="card-text mb-1">Harga: <strong>Rp 145.000</strong></p>
        <p class="card-text mb-1">Jumlah: <strong>1</strong></p>
        <p class="card-text">Subtotal: <strong>Rp 145.000</strong></p>
        <a href="#" class="btn btn-outline-danger btn-sm">Hapus</a>
      </div>
    </div>
  </div>
</div>
<div class="card mt-4">
  <div class="card-body d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
    <div>
      <h6 class="mb-1">Total Keranjang</h6>
      <p class="mb-0 fs-5"><strong>Rp 690.000</strong></p>
    </div>
    <a href="#" class="btn btn-primary">Lanjut ke Checkout</a>
  </div>
</div>
<?= $this->endSection() ?>