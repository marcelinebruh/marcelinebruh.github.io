<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
  /* Aturan agar semua gambar card seragam */
  .card-img-top {
    width: 100%;
    height: 200px; /* tinggi seragam */
    object-fit: cover; /* crop otomatis biar proporsional */
  }
</style>

<div class="row">
  <div class="col-12">
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-primary text-white">
        <h5 class="card-title mb-0">Profil Orang</h5>
      </div>
      <div class="card-body">
        <div class="row">
          <!-- Card Profil 1 -->
          <div class="col-md-4">
            <div class="card h-100 shadow-sm">
              <img src="data:image/jpeg;base64,..." class="card-img-top" alt="Foto Profil">
              <div class="card-body">
                <h5 class="card-title">Budi Santoso</h5>
                <p class="card-text"><strong>Email:</strong> budi@example.com</p>
                <p class="card-text"><strong>Role:</strong> Mahasiswa</p>
                <p class="card-text text-muted">Aktif di organisasi kampus dan suka programming.</p>
              </div>
            </div>
          </div>

          <!-- Card Profil 2 -->
          <div class="col-md-4">
            <div class="card h-100 shadow-sm">
              <img src="data:image/jpeg;base64,..." class="card-img-top" alt="Foto Profil">
              <div class="card-body">
                <h5 class="card-title">Rusdy Hsndoko</h5>
                <p class="card-text"><strong>Email:</strong> rusdy@example.com</p>
                <p class="card-text"><strong>Role:</strong> Dosen</p>
                <p class="card-text text-muted">Mengajar mata kuliah Teori Bahasa & Automata.</p>
              </div>
            </div>
          </div>

          <!-- Card Profil 3 -->
          <div class="col-md-4">
            <div class="card h-100 shadow-sm">
              <img src="data:image/jpeg;base64,..." class="card-img-top" alt="Foto Profil">
              <div class="card-body">
                <h5 class="card-title">Andi Wijaya</h5>
                <p class="card-text"><strong>Email:</strong> andi@example.com</p>
                <p class="card-text"><strong>Role:</strong> Admin</p>
                <p class="card-text text-muted">Mengelola sistem dan database kampus.</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
