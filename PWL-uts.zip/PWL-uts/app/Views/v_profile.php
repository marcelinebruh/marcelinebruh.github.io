<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<style>
/* Background halaman utama */
body {
  background: #eef2f7; /* abu-abu lembut */
}

/* Card profil */
.profile-card {
  max-width: 700px;
  margin: 40px auto;
  padding: 30px;
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 6px 15px rgba(0,0,0,0.1);
  font-family: "Segoe UI", Arial, sans-serif;
}

/* Header card dengan warna */
.profile-card h4 {
  font-size: 26px;
  font-weight: 600;
  color: #fff;
  margin: -30px -30px 25px -30px; /* full width header */
  padding: 15px 30px;
  background: #007bff; /* biru */
  border-radius: 12px 12px 0 0;
}

/* Item detail */
.profile-item {
  display: flex;
  justify-content: space-between;
  padding: 14px 12px;
  border-bottom: 1px solid #e0e0e0;
}

.profile-item:nth-child(even) {
  background-color: #f9f9f9; /* selang-seling */
}

.profile-item span {
  font-weight: 500;
  color: #555;
}

.profile-item strong {
  color: #007bff;
}
</style>

<div class="profile-card">
    <h4>Profil Pengguna</h4>
    <div class="profile-item"><span>Username:</span> <strong><?= esc($username) ?></strong></div>
    <div class="profile-item"><span>Role:</span> <strong><?= esc($role) ?></strong></div>
    <div class="profile-item"><span>Email:</span> <strong><?= esc($email) ?></strong></div>
    <div class="profile-item"><span>Waktu Login:</span> <strong><?= esc($waktu_login) ?></strong></div>
    <div class="profile-item"><span>Status Login:</span> <strong><?= esc($status_login) ?></strong></div>
</div>

<?= $this->endSection() ?>
